# Be sure to restart your server when you modify this file.

# ActiveSupport::Reloader.to_prepare do
#   ApplicationController.renderer.defaults.merge!(
#     http_host: 'example.org',
#     https: false
#   )
# end

Refile.secret_key = 'bf9b3c244b360e86d81350f26c2a908b7bdda19bd597f97c5cbdf5a6d157bf44087453ef25ac8d72c6deab24419fc54b8600bd71d6c01b0b1d5df4454988f8cc'